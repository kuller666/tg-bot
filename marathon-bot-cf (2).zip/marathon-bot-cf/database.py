import sqlite3
import datetime
import os
from typing import Optional, List, Dict

class Database:
    def __init__(self):
        # Используем /tmp для Render (временное хранилище)
        self.db_path = '/tmp/marathon.db'
        self.init_db()
    
    def init_db(self):
        """Инициализация базы данных"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Таблица пользователей
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                join_date TIMESTAMP,
                current_day INTEGER DEFAULT 1,
                completed_days TEXT DEFAULT '',
                last_activity TIMESTAMP
            )
        ''')
        
        # Таблица уроков
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS lessons (
                day_number INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                media_type TEXT,
                media_file_id TEXT,
                is_active INTEGER DEFAULT 1,
                created_date TIMESTAMP
            )
        ''')
        
        # Добавляем тестовые уроки, если их нет
        cursor.execute('SELECT COUNT(*) FROM lessons')
        if cursor.fetchone()[0] == 0:
            for i in range(1, 8):
                cursor.execute('''
                    INSERT INTO lessons (day_number, title, content, created_date)
                    VALUES (?, ?, ?, ?)
                ''', (i, f"День {i}", f"Содержание урока {i}", datetime.datetime.now()))
        
        conn.commit()
        conn.close()
    
    def add_user(self, user_id: int, username: str = None, first_name: str = None, last_name: str = None):
        """Добавление нового пользователя"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT OR IGNORE INTO users 
            (user_id, username, first_name, last_name, join_date, last_activity)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (user_id, username, first_name, last_name, datetime.datetime.now(), datetime.datetime.now()))
        
        conn.commit()
        conn.close()
    
    def get_user(self, user_id: int) -> Optional[Dict]:
        """Получение информации о пользователе"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
        row = cursor.fetchone()
        
        conn.close()
        
        if row:
            return {
                'user_id': row[0],
                'username': row[1],
                'first_name': row[2],
                'last_name': row[3],
                'join_date': row[4],
                'current_day': row[5],
                'completed_days': row[6],
                'last_activity': row[7]
            }
        return None
    
    def update_user_progress(self, user_id: int, day: int):
        """Обновление прогресса пользователя"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT completed_days FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        
        if result:
            completed_days = result[0] if result[0] else ""
            if str(day) not in completed_days:
                completed_days = completed_days + str(day) if completed_days else str(day)
            
            cursor.execute('''
                UPDATE users 
                SET completed_days = ?, current_day = ?, last_activity = ?
                WHERE user_id = ?
            ''', (completed_days, min(day + 1, 7), datetime.datetime.now(), user_id))
        
        conn.commit()
        conn.close()
    
    def get_lesson(self, day_number: int) -> Optional[Dict]:
        """Получение урока по номеру дня"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT * FROM lessons 
            WHERE day_number = ? AND is_active = 1
        ''', (day_number,))
        row = cursor.fetchone()
        
        conn.close()
        
        if row:
            return {
                'day_number': row[0],
                'title': row[1],
                'content': row[2],
                'media_type': row[3],
                'media_file_id': row[4],
                'is_active': row[5],
                'created_date': row[6]
            }
        return None

# Глобальная переменная для базы данных
db = Database()