from flask import Flask, request, jsonify
import telebot
import os
import threading
from bot import get_bot

app = Flask(__name__)

# Получаем бота
bot = get_bot()

@app.route('/')
def home():
    return "Telegram Bot is running on Render!"

@app.route('/webhook', methods=['POST'])
def webhook():
    # Получаем данные от Telegram
    json_string = request.get_data().decode('utf-8')
    update = telebot.types.MessageUpdate.de_json(json_string)
    bot.process_new_updates([update])
    return "!", 200

if __name__ == '__main__':
    # Локальный запуск для тестирования
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)