import os

# Токен бота (будем задавать в Render)
BOT_TOKEN = os.getenv('BOT_TOKEN', '')

# ID администраторов
ADMIN_IDS = [int(x) for x in os.getenv('ADMIN_IDS', '').split(',') if x]