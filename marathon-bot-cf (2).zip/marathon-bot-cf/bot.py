import telebot
from telebot import types
import config
from database import db
import os

# Инициализация бота
BOT_TOKEN = os.getenv('BOT_TOKEN', '')
bot = telebot.TeleBot(BOT_TOKEN)

# Состояния пользователей
user_states = {}

# Состояния
STATE_NEW_USER = "new_user"
STATE_ACTIVE = "active"
STATE_FINISHED = "finished"

def get_main_keyboard(user_id):
    """Создание основной клавиатуры"""
    user = db.get_user(user_id)
    if not user:
        return None
    
    keyboard = types.InlineKeyboardMarkup()
    
    completed_days = user['completed_days'] if user['completed_days'] else ""
    current_day = user['current_day']
    
    if len(completed_days) >= 7:
        keyboard.add(types.InlineKeyboardButton("🏆 Мой сертификат", callback_data="certificate"))
        keyboard.add(types.InlineKeyboardButton("📊 Мой прогресс", callback_data="progress"))
    else:
        if str(current_day) not in completed_days:
            keyboard.add(types.InlineKeyboardButton(f"📚 День {current_day}", callback_data=f"day_{current_day}"))
            keyboard.add(types.InlineKeyboardButton("✅ Плюсик (Выполнено)", callback_data=f"complete_{current_day}"))
        else:
            next_day = min(current_day + 1, 7)
            keyboard.add(types.InlineKeyboardButton(f"📚 День {next_day}", callback_data=f"day_{next_day}"))
        
        keyboard.add(types.InlineKeyboardButton("📊 Мой прогресс", callback_data="progress"))
    
    return keyboard

def get_welcome_keyboard():
    """Клавиатура после приветственного видео"""
    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(types.InlineKeyboardButton("▶️ Далее", callback_data="start_marathon"))
    return keyboard

@bot.message_handler(commands=['start'])
def start_command(message):
    """Обработка команды /start"""
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name
    last_name = message.from_user.last_name
    
    db.add_user(user_id, username, first_name, last_name)
    user_states[user_id] = STATE_NEW_USER
    
    welcome_text = "👋 Добро пожаловать в 7-дневный марафон!\n\nПосмотрите приветственное видео:"
    bot.send_message(user_id, welcome_text)
    
    bot.send_message(user_id, "🎥 [Здесь будет ваше приветственное видео]")
    bot.send_message(user_id, "Готовы начать марафон?", reply_markup=get_welcome_keyboard())

@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    """Обработка callback-запросов"""
    user_id = call.from_user.id
    data = call.data
    
    try:
        if data == "start_marathon":
            user_states[user_id] = STATE_ACTIVE
            bot.edit_message_text(
                chat_id=user_id,
                message_id=call.message.message_id,
                text="🎯 Отлично! Начинаем марафон!\n\nПервый день уже доступен:",
                reply_markup=get_main_keyboard(user_id)
            )
        
        elif data.startswith("day_"):
            day_number = int(data.split("_")[1])
            lesson = db.get_lesson(day_number)
            
            if lesson:
                lesson_text = f"📖 <b>{lesson['title']}</b>\n\n{lesson['content']}"
                bot.send_message(user_id, lesson_text, parse_mode="HTML")
            else:
                bot.answer_callback_query(call.id, "Урок пока не готов")
        
        elif data.startswith("complete_"):
            day_number = int(data.split("_")[1])
            user = db.get_user(user_id)
            
            if user:
                completed_days = user['completed_days'] if user['completed_days'] else ""
                
                if str(day_number) not in completed_days:
                    db.update_user_progress(user_id, day_number)
                    
                    if day_number == 7:
                        congrats_text = "🎉 ПОЗДРАВЛЯЕМ!\n\nВы успешно завершили 7-дневный марафон! 🏆\n\nВаш сертификат готов!"
                        bot.send_message(user_id, congrats_text)
                        bot.send_message(user_id, "📜 [Здесь будет ваш сертификат]")
                    else:
                        bot.answer_callback_query(call.id, f"День {day_number} отмечен как выполненный! ✅")
                else:
                    bot.answer_callback_query(call.id, "Этот день уже завершен!")
            
            try:
                bot.edit_message_reply_markup(
                    chat_id=user_id,
                    message_id=call.message.message_id,
                    reply_markup=get_main_keyboard(user_id)
                )
            except:
                pass
        
        elif data == "progress":
            user = db.get_user(user_id)
            if user:
                completed_days = user['completed_days'] if user['completed_days'] else ""
                current_day = user['current_day']
                
                progress_text = f"📊 <b>Ваш прогресс</b>\n\n"
                progress_text += f"📅 День: {current_day}/7\n"
                progress_text += f"✅ Выполнено: {len(completed_days)}/7 дней\n"
                
                progress_bar = "▓" * len(completed_days) + "░" * (7 - len(completed_days))
                progress_text += f".ProgressBar: [{progress_bar}] {int(len(completed_days)/7*100)}%\n\n"
                
                if len(completed_days) >= 7:
                    progress_text += "🏆 Марафон завершен! Поздравляем!"
                else:
                    progress_text += f"Продолжайте в том же духе!"
                
                bot.send_message(user_id, progress_text, parse_mode="HTML")
        
        elif data == "certificate":
            bot.send_message(user_id, "📜 Ваш сертификат об участии в марафоне:")
            bot.send_message(user_id, "🏆 [Здесь будет изображение сертификата]")
    
    except Exception as e:
        print(f"Ошибка: {e}")
        bot.answer_callback_query(call.id, "Произошла ошибка")

@bot.message_handler(commands=['help'])
def help_command(message):
    """Команда помощи"""
    help_text = """
❓ <b>Помощь по боту</b>

📚 <b>Как пользоваться:</b>
1. Сканируйте QR-код
2. Смотрите приветственное видео
3. Нажмите "Далее"
4. Проходите уроки по дням
5. Отмечайте выполнение кнопкой "Плюсик"

📊 <b>Команды:</b>
/start - Начать марафон
/help - Помощь

💡 Удачи в марафоне!
    """
    bot.send_message(message.chat.id, help_text, parse_mode="HTML")

# Экспортируем бота для веб-сервера
def get_bot():
    return bot